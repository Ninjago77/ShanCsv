class ShanCsvError(Exception):
	pass

class ShanCsvIndexError(IndexError):
	pass

class ShanCsvNotImplemented(NotImplementedError):
	pass